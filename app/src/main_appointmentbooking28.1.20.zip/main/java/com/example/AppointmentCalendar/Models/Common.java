package com.example.AppointmentCalendar.Models;


import android.os.Environment;


public class Common {

    public static Booking _bookingdetails= null;
    public static String ExternalSDPath = Environment.getExternalStorageDirectory().getAbsolutePath() ;
    public static String appfolder_main = "AppointmentCalender";
}
