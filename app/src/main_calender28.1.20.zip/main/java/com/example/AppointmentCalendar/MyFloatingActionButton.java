package com.example.AppointmentCalendar;

import android.content.Context;
import android.content.res.ColorStateList;
import android.support.design.widget.FloatingActionButton;
import android.util.AttributeSet;

class MyFloatingActionButton extends FloatingActionButton {
    public MyFloatingActionButton(Context context) {
        super(context);
    }

    public MyFloatingActionButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MyFloatingActionButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
//    public int setColors(int textColor, int accentColor, int backgroundColor) {
////        backgroundTintList = ColorStateList.valueOf(accentColor);
////        applyColorFilter(accentColor.getContrastColor());
//        }

//        constructor(context: Context, attrs: AttributeSet) : super(context, attrs)
//
//        constructor(context: Context, attrs: AttributeSet, defStyle: Int) : super(context, attrs, defStyle)
//
//        fun setColors(textColor: Int, accentColor: Int, backgroundColor: Int) {
//        backgroundTintList = ColorStateList.valueOf(accentColor)
//        applyColorFilter(accentColor.getContrastColor())
//        }
        }
