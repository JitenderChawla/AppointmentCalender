package com.example.AppointmentCalendar.Interface;

import com.example.AppointmentCalendar.Models.MonthModel;

public interface MonthChangeListner {
    void onmonthChange(MonthModel monthModel);
}
